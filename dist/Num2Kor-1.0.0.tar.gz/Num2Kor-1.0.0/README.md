# Num2Kor 
Convert Number into Korean Words! <br>
Inspired by [huskyhoochu/num-to-korean](https://github.com/huskyhoochu/num-to-korean)